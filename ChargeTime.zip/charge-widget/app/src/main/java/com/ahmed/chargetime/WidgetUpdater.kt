package com.ahmed.chargetime

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.widget.RemoteViews

object WidgetUpdater {

    private const val PREFS = "charge_prefs"

    fun update(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(ComponentName(context, BatteryWidget::class.java))
        if (ids.isEmpty()) return

        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return

        val pct = level * 100 / scale
        val full = status == BatteryManager.BATTERY_STATUS_FULL || pct >= 100
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || full

        val remainingMs = trackAndEstimate(context, pct, charging && !full)

        val (title, main, sub) = when {
            full -> Triple("الشحن مكتمل", "١٠٠٪", "افصل الشاحن")
            charging && remainingMs > 0 -> Triple(
                "متبقي حتى ١٠٠٪",
                formatDuration(remainingMs),
                "البطارية الآن ${arabicDigits(pct.toString())}٪"
            )
            charging -> Triple(
                "جاري الشحن",
                "...",
                "البطارية ${arabicDigits(pct.toString())}٪ — جاري حساب الوقت"
            )
            else -> Triple(
                "غير موصّل بالشاحن",
                "${arabicDigits(pct.toString())}٪",
                "وصّل الشاحن لعرض الوقت"
            )
        }

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val views = RemoteViews(context.packageName, R.layout.widget).apply {
            setTextViewText(R.id.tvTitle, title)
            setTextViewText(R.id.tvTime, main)
            setTextViewText(R.id.tvSub, sub)
            setProgressBar(R.id.progress, 100, pct, false)
            setOnClickPendingIntent(R.id.root, open)
        }
        mgr.updateAppWidget(ids, views)
    }

    /** Returns remaining ms to 100%, or -1 if unknown. */
    private fun trackAndEstimate(context: Context, pct: Int, charging: Boolean): Long {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val wasCharging = prefs.getBoolean("was_charging", false)
        val now = System.currentTimeMillis()

        if (!charging) {
            prefs.edit().putBoolean("was_charging", false).apply()
            return -1
        }
        if (!wasCharging) {
            prefs.edit()
                .putBoolean("was_charging", true)
                .putLong("start_time", now)
                .putInt("start_level", pct)
                .apply()
        }

        // 1) The system's own estimate (Android 9+), when the device provides it.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val sys = bm.computeChargeTimeRemaining()
            if (sys > 0) return sys
        }

        // 2) Fallback: extrapolate from the charging speed since plug-in.
        val startTime = prefs.getLong("start_time", now)
        val startLevel = prefs.getInt("start_level", pct)
        val gained = pct - startLevel
        val elapsed = now - startTime
        if (gained >= 1 && elapsed > 0) {
            return elapsed / gained * (100 - pct)
        }
        return -1
    }

    private fun formatDuration(ms: Long): String {
        val totalMin = ((ms + 59_999) / 60_000).toInt()
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 && m > 0 -> "${arabicDigits(h.toString())} س ${arabicDigits(m.toString())} د"
            h > 0 -> "${arabicDigits(h.toString())} س"
            else -> "${arabicDigits(m.toString())} د"
        }
    }

    private fun arabicDigits(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '0'..'9') ('٠' + (c - '0')) else c)
        return sb.toString()
    }
}
