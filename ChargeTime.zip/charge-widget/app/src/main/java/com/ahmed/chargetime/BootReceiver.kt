package com.ahmed.chargetime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        BatteryService.start(context)
        WidgetUpdater.update(context)
    }
}
