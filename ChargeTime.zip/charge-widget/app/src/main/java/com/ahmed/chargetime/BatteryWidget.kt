package com.ahmed.chargetime

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class BatteryWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        BatteryService.start(context)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.update(context)
        BatteryService.start(context)
    }
}
