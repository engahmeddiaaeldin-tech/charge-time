package com.ahmed.chargetime

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        BatteryService.start(this)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "وقت اكتمال الشحن"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "أضف الويدجت إلى الشاشة الرئيسية ليعرض الوقت المتبقي حتى ١٠٠٪.\n\n" +
                "لو الوقت لم يتحدّث، اسمح للتطبيق بالعمل في الخلفية من إعدادات البطارية."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        val add = Button(this).apply {
            text = "إضافة الويدجت للشاشة الرئيسية"
            setOnClickListener {
                val mgr = getSystemService(AppWidgetManager::class.java)
                if (mgr.isRequestPinAppWidgetSupported) {
                    mgr.requestPinAppWidget(ComponentName(context, BatteryWidget::class.java), null, null)
                } else {
                    hint.text = "اضغط مطولًا على الشاشة الرئيسية ← الويدجت ← وقت اكتمال الشحن."
                }
            }
        }

        root.addView(title)
        root.addView(hint)
        root.addView(add)
        setContentView(root)

        WidgetUpdater.update(this)
    }
}
